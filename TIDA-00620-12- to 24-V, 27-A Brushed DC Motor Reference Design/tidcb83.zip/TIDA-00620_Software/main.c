//***************************************************************************************
// MSP430 DRV8701 Motor Driver Control
//
// Description; Take the input from a potentiometer connected to 3.3 Volts and Pin 1.4 on
// MSP430 and translate that voltage to control the PWM Duty Cycke output on pin 2.1 using Timer
// A and up Mode.  This code also poles the state of a toggle switch used to change the
// direction of the motors spin.  Timer A1.0 is configured to pole the value of the ADC /
// state of the position switch every 1 ms, make any necessary changes, then return to Low
//	Power Mode.
//
// MSP430x2xx
//
// Philip Beard
// Texas Instruments, Inc
// August 2015
// Built with Code Composer Studio v5
//***************************************************************************************

#include <msp430g2553.h>

int Speed;
int Temp;
int Battery_Voltage;

void Speed_Pole();
void Temp_Monitor();
void Battery_Monitor();

void main(void)
{
	WDTCTL = WDTPW + WDTHOLD;	// Stop Watch Dog Timer

	DCOCTL = CALDCO_8MHZ;		// Calibrate DCO to 8 MHz as opposed to default 1 MHz
	BCSCTL1 = CALBC1_8MHZ;

	P2DIR |= BIT4;		// Set Direction of P2.4 as output
	P2SEL &= (~BIT4);	// Set P2.4 as GPIO
	P2OUT |= BIT4;		// Set state of P2.4 to high

	TA0CCTL0 = CCIE;			// CCR0 interrupt enabled
	TA0CTL = TASSEL_2 + MC_1;	// SMCLK, upmode
	TA0CCR0 =  8000;			// Trigger interrupt once every 1 ms (8000 / 8MHz = 1ms)
	P1OUT &= 0x00;				// Clear Registers
	P1DIR &= 0x00;

// GPIO Pins

	P1DIR &= (~BIT3);					// Set Direction of P1.3
	P1SEL &= (~BIT3);					// Set P1.3 as a GPIO Pin
	P2DIR &= ~BIT3 + ~BIT7;				// Set Pin 2.3 and 2.7 as an input
	P2DIR|=(BIT1+BIT5);					// Set Pin 2.1 and 2.5 as outputs
	P2SEL &= (~BIT7)+(~BIT5)+(~BIT3);	// Set Pin 2.7, 2.5, 2.3 as GPIO
	P2SEL|=BIT1;						// Route TA1.1 to output pin
	P2REN |= BIT3 + BIT7;				// Assign Pull Up Resistor to P2.3 and P2.7

// PWM Initialization

	TA1CCR0 = 255; 				// PWM Period, maximum value for Timer A1 (8 MHz / 255 = 31.372 kHz)
	TA1CCTL1 = OUTMOD_7; 		// CCR1 reset/set
	TA1CTL = TASSEL_2 + MC_1;	// Chooses SMCLK and Up Mode

// Initializing ADC

    ADC10CTL0 = ADC10SHT_3 | ADC10ON;
    ADC10CTL1 = INCH_4;
    ADC10AE0  = BIT4;
    ADC10CTL0 |= ENC + ADC10SC;
    while (ADC10CTL1 & ADC10BUSY);
    Speed = ADC10MEM;

// Status Light

	P1DIR |= BIT0;
	P1SEL &= (~BIT0);
	P1OUT |= BIT0;			// Set state of P1.0 to high (Status Light)

	_BIS_SR(CPUOFF + GIE);	// Enter LPM0 with interrupts
}

// ADC Sample Function
void Speed_Pole(void)
{

    ADC10CTL0 &= ~ENC;
    ADC10CTL1 = INCH_4;
    ADC10AE0  = BIT4;
    ADC10CTL0 |= ENC + ADC10SC;
    while (ADC10CTL1 & ADC10BUSY);
    Speed = ADC10MEM;

}
// Battery Monitor Control
// REQUIRES RESTARTING DEVICE IF TRIGGERED
// Vm < 10 or Vm > 28 V
void Battery_Monitor(void)
{

    ADC10CTL0 &= ~ENC;
    ADC10CTL1 = INCH_7;
    ADC10AE0  = BIT7;
    ADC10CTL0 |= ENC + ADC10SC;
    while (ADC10CTL1 & ADC10BUSY);
    Battery_Voltage = ADC10MEM;

	if (Battery_Voltage < 217 || Battery_Voltage > 620){
		P2OUT &= ~BIT4;				// Set state of P2.4 to low, putting DRV8701 to sleep and shutting down MSP430 / DRV8701
	}
	else{
	}
}

// Temp Monitor
// Interupts at 130 deg Celsius, stops PWM signal
void Temp_Monitor(void)
{
    ADC10CTL0 &= ~ENC;
    ADC10CTL1 = INCH_6;
    ADC10AE0  = BIT6;
    ADC10CTL0 |= ENC + ADC10SC;
    while (ADC10CTL1 & ADC10BUSY);
    Temp = ADC10MEM;

	if (Temp < 202) {
		Speed=0;
	}
	else{
	}
}

// Timer A0 interrupt service routine
#pragma vector=TIMER0_A0_VECTOR
__interrupt void Timer_A (void)
{

	if((P1IN & BIT3) == BIT3){		// If P1.3 is pulled high then pull Pin 2.5 high
		P2OUT |= BIT5;				// Set State of Pin 2.5 as high
	}
	else{							// If P1.3 is intially pulled low then pull Pin 2.5 low
		P2OUT &= (~BIT5);			// Set state of Pin 2.5 as low
	}

	Battery_Monitor();
	Speed_Pole();
	Temp_Monitor();

	TA1CCR1 = (Speed/4);			// Normalize 10BitADC Speed Value to 8Bit Timer A and write to TA1CCR1 Register

}



